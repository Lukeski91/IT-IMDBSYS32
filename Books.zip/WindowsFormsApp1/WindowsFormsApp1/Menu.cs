﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void borrowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Borrow bo = new Borrow();
            bo.ShowDialog();
        }

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Books bok = new Books();
            bok.ShowDialog();
        }

        private void borrowedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Borrowed bor = new Borrowed();
            bor.ShowDialog();
        }

        private void returnedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Returned ret = new Returned();
            ret.ShowDialog();
        }
    }
}
